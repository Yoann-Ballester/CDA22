package tp5;

import java.util.Scanner;

public class Exo5_v2 {
	
		
		static final int nbdiv =7;

		public static void main(String[] args) {
			
			
			Scanner scanner = new Scanner(System.in);
			   
			 
			 System.out.println("Saisir une valeur max");
		     int max = scanner.nextInt();
		     
		     System.out.println("Saisire valeur de du multiple");
		     int nbdiv = scanner.nextInt();
			

			System.out.println("\nAffichage des MULTIPLES de " +nbdiv+" entre 0 et 100\n");
			
			
			
			for (int x=0;x<=max;x++) {
				if (x%nbdiv ==0)
					System.out.print("("+x+")\t");
				
				if (x%25==0)
					System.out.print(" \n");
				
				if (x%nbdiv!=0)
					System.out.print(" "+x+" \t");
				
				
			}
			
			
		}

	

	}

