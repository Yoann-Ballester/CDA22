package argProg;

import java.util.Arrays;

public class TriParam {

	public static void main(String ... args) {
		
		
		Arrays.sort(args);
		
		/* "Usage : ajouter des arguments dans le main via les paramètres afin des les faire apparaitre sous forme de tableau." */
		for (String value : args) {
			
			
			
			System.out.println(value);
			
			if (args == null) {
				
				System.out.print("Usage : ajouter des arguments dans le main via les paramètres afin des les faire apparaitre sous forme de tableau.");
			}
			
			
			//Arrays.sort(Object[]a, 0,3);
			
			
			
			
		}
	}

}
