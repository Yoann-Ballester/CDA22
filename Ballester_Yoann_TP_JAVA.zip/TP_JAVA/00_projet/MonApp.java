public class MonApp {

public static void main(String[]arg) {
		System.out.println("Hello world");
	}

}