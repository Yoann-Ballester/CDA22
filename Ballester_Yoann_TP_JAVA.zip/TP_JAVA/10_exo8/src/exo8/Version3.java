package exo8;

import java.util.Scanner;

public class Version3 {

		/** nbdiv est la variable correspondant au multiple que nous souhaitons rechercher.                      */
		static final int nbdiv =7;

		public static void main(String[] args) {
			
			
			Scanner scanner = new Scanner(System.in);
			   
			 /** L'operateur saisie la range maximale dans laquelle le programme devra rechercher un multiple (nbdiv).  */
			 System.out.println("Saisir une valeur max");
		     int max = scanner.nextInt();
		     
		     
		     /** L'operateur saisie la valeur de nbdiv qui est une variable correspondant à un multiple. Exemple: si l'on entre 12, le programme mettra en évidence les multiples de 12  */
		     System.out.println("Saisire valeur de du multiple");
		     int nbdiv = scanner.nextInt();
			
		     
		     
			System.out.println("\nAffichage des MULTIPLES de " +nbdiv+" entre 0 et 100\n");
			
			
			/** affichage des nombres dans l'intervalle (max) definit par l'operateur, et mise en évidence des nombres multiple parmis ceux-ci */
			for (int x=0;x<=max;x++) {
				if (x%nbdiv ==0)
					System.out.print("("+x+")\t");
				
				if (x%25==0)
					System.out.print(" \n");
				
				if (x%nbdiv!=0)
					System.out.print(" "+x+" \t");

			}

		}
		
}
