package equestre.libconsole;

public class MonEssai {

public static void main(String[] args)
{
	System.out.print("Entrez une chaine quelconque :");
	String chaineSaisie= fr.afpa.outils.Console.in.readLine();
	System.out.println();
	System.out.println("Voici la chaine que vous"
			+ " avez saisie :" + chaineSaisie);
}

}
