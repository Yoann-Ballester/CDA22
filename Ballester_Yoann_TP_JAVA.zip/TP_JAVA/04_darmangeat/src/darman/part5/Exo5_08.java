package darman.part5;

import java.util.Scanner;

public class Exo5_08 {

	public static void main(String[] args) {

		
		 Scanner scanner = new Scanner(System.in); 
		   
		 int max =1;
		 int i;
		 for (i=1;i>19;i++) {
			 
			
		 System.out.println("Saisir un nombre");
	     int s = scanner.nextInt();
     
	     if (max<s) {
	    	 max=s;
	     }
	     
	     if (i>19) {
	    	 System.out.print(max);
	     }
	
		
		 }
	}

}
