package darman.part6;


public class Exo6_02 {

	public static void main(String[] args) {

			int a=3;
			int b=7;
			
			if (a+b==8)
				System.out.print("True");
			
			if (a+b!=8)
				System.out.print("False");
			
		}
	}

