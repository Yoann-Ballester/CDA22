package darman.part6;

public class Exo6_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
int [] myArray = {0,0,0,0,0,0,0};
		
		for (int value : myArray) {
			System.out.println(value);
		}
		
	}

}
