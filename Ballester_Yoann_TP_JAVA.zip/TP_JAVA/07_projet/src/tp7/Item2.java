package tp7;

import java.util.Arrays;

public class Item2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	
	String [] tab = {"coucou","hello","glfdkgl", "aurevoir","fdsfg", "jkjgl","klmdkf", "mpfgopd", "ejkgjl", "tjkjlg"};
	
	
	
	for (String val : tab) {
		System.out.print(" "+val+" ");
			
			
		}
	
	System.out.print(" \n");
	
	
	
	String [] tab2 = tab;
	Arrays.sort(tab2);
	
	for (String val2 : tab2) {
	
	
	System.out.print(" "+val2+" ");
	}
	
	System.out.print(" \n");
	
	StringBuffer [] t3= {new StringBuffer ("bonjour"),new StringBuffer ("hello"),new StringBuffer ("coucou")};
	
	for (StringBuffer w : t3) {
		
		
		System.out.print(" "+w+" ");
		}
	
	}
	
 }

