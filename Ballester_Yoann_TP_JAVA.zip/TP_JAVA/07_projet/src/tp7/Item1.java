package tp7;

public class Item1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int [] myArray = {1,100,45,23,3,4,8,9,78,43};
		
		for (int value : myArray) {
			System.out.println(value);
		}
		
		System.out.println("\n");
		
		// copie de reference
		
		int[] myArray2=myArray;
		
		for (int value2 : myArray2) {
			System.out.println(value2);
		}
		
		System.out.println("\n");
		
		int [] myArray3=myArray.clone();
		
		for (int value3 : myArray3) {
			System.out.println(value3);
		}
		

	}
}
