package exo9;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		String s2 = "nbjt d ftu qbt m ifvsf ef bpf 4 mb";

		System.out.println("\n \n"+s2+" signifie : ");
		
		int v = s2.length();
		int k=1;
		while (k<=100) {
		k++;
		for (int j=0;j<v;j++) {
			
			int w = s2.charAt(j);
			w=w-k;
			
//			if (w<97)
//				w= 122-(w-97);
//			
//			if (w>122)
//				w= 97+(w-122);
			
			
			char n = (char) w;
			
			//System.out.print(c+" ");
			System.out.print(n);

			//System.out.print(" "+c);
			}
		}
	}

}
