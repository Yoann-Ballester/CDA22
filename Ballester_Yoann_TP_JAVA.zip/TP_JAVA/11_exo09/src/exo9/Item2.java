package exo9;

import java.util.Scanner;

public class Item2 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.print("Entrez un mot : ");
		 String s = scanner.nextLine();
	//	String s="Aurevoir";
		 

			System.out.println(s+" en unicode est :");
		
		int t = s.length();
		
		for (int i=0;i<t;i++) {
			
			char c = s.charAt(i);
			
			
			System.out.print( "\\u" + Integer.toHexString(c | 0x10000).substring(1)+" " );

			//System.out.print(" "+c);
		}
		
		
	}

}
