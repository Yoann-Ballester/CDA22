package exo9;



public class Item3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
		String s = "Test";

		System.out.println(s+" en code signifie : ");
		
		int t = s.length();
		
		for (int i=0;i<t;i++) {
			
			int c = s.charAt(i);
			c=c+1;
			
			if (c>122)
				c= 97+(c-122);
			
			
			char r = (char) c;
			
			//System.out.print(c+" ");
			System.out.print(r);

			//System.out.print(" "+c);
		}
		
		// DECRYPTAGE
		////////////////////
		
		String s2 = "Uftu";

		System.out.println("\n \n"+s2+" signifie : ");
		
		int v = s2.length();
		
		for (int j=0;j<v;j++) {
			
			int w = s2.charAt(j);
			
			
			w=w-1;
			
			if (w>122)
				w= 97+(w-122);
			
			
			char n = (char) w;
			
			
			//System.out.print(c+" ");
			System.out.print(n);

			//System.out.print(" "+c);
		}
	}
}
