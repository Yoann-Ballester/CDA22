public class Item3 {
	public static void main (String[]args){
		byte c = 70;
		byte d = 70;
		byte e;
		
		e = (byte)(c + d);		
		System.out.println("valeur de e: " + e);
	}
}