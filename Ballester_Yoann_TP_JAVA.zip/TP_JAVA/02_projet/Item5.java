import java.io.*;
import java.lang.Math.*;

public class Item5 {
	public static void main (String[]args){
		
		
	
			
			int x=4;
			double rcarre = Math.sqrt(x);
			
			double y= 3.14159265359/2;
			double cosinus = Math.cos((double) y);
			
			
			
			System.out.println("la racine carrée de 4 est : "+rcarre+"\n Le cosinus de pi/2 est :"+cosinus );
		
		int min = 1;
		int max = 10;
        
       
      System.out.println("valeur aléatoire entre "+min+" et "+max+ ":");
      int random_int = (int)Math.floor(Math.random()*(max-min+1)+min);
		System.out.println(random_int);
	
	int random_int1 = (int)Math.floor(Math.random()*(max-min+1)+min);
		System.out.println(random_int1);
		int random_int2 = (int)Math.floor(Math.random()*(max-min+1)+min);
		System.out.println(random_int2);
		int random_int3 = (int)Math.floor(Math.random()*(max-min+1)+min);
		System.out.println(random_int3);
		int random_int4 = (int)Math.floor(Math.random()*(max-min+1)+min);
		System.out.println(random_int4);
	}
}