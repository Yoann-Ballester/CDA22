public class Item2 {
	public static void main (String[]args){
		
		int a=1;
		int b=1;
		
		System.out.println(a+"+"+b+"="+(a+b));
	}
}