public class Item1 {
	public static void main (String[]args){
		
		int x,y;
		x = 3;
		y= 2;
		double a=x/y;
		double f=a*y;
		
		System.out.println((int)(f*f)-1);
	}
}