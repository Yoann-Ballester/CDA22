package exo7;

public class Item1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		short i;
		for (i=1;i<40000;i=(short) (i+1000)) {
			
			System.out.println(i);
		}

		
		// le short a une range de -32,768 to 32,767 ce qui fait boucle le compteur à l'infini
		
	}

}
