package exo7;

public class Item4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		double a=456789.7890123456789;
		int b;
		char c;
		float d;
		short e;
		byte f;
		long g;
		
		b=(int) a;
		c=(char) a;
		d=(float) a;
		e=(short) a;
		f=(byte) a;
		g=(long) a;
		
		System.out.println(a+ " \n"+ b+" "+ c+"\n "+ d+" \n"+ e+"\n "+ f+"\n "+ g);
		
	}

}
