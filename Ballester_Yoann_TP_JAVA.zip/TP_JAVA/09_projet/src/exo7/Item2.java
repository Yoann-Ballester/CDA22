package exo7;

import java.util.Scanner;

public class Item2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	 Scanner scanner = new Scanner(System.in);
	     System.out.println("Entrez un char");
	     char i = scanner.next().charAt(0);

		
		
		if (i>='a' && i<='z') {
			
			i-=32;
			System.out.print(i);
		}
		

		
	}

}
