package exo7;

import java.util.Scanner;

public class Item3 {

	static double y=Math.PI;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner = new Scanner(System.in);
	     System.out.println("Entrez un diametre de cercle");
	     double x = scanner.nextDouble();

		
	//	double aire=y*(x/2)*(x/2);
		
		double aire2=(y*Math.pow(x, 2))/4;
		
		System.out.print(aire2+" m²");
		
		// inputMusmatchException
	}
		
}
