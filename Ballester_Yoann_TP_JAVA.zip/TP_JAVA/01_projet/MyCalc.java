import java.util.Scanner;

import java.io.*;
import java.lang.Math;

public class MyCalc {

public static void main(String[]arg) {
		
	
		System.out.println("Entrez une valeur :");
		
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		
		
		System.out.println("la valeur saisie est:"+x);
		
		
		
		int i=0;
		
		for (i=x;x>0;x=x-1){
			
			int carre = (int)Math.pow((int) x,(int) 2);
			int rcarre = (int)Math.sqrt((int) x);
			
			System.out.println("\n La valeur est :"+x+"\n son carré est : "+carre+"\n sa racine carrée est : "+rcarre);
		}
	}

}