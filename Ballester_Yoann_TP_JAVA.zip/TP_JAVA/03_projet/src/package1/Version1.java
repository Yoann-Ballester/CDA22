package package1;

import java.util.Scanner;

public class Version1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String nom,prenom,pref1,pref2,pref3,adresse,fnte;
		char rep;
		
		do {
			// saisie
			
			System.out.println("Nom du cavalier\t: ");
			nom = sc.nextLine();
			System.out.println("Prenom du cavalier\t: ");
			prenom = sc.nextLine();
			
			System.out.println("Adresse du cavalier\t: ");
			adresse = sc.nextLine();
			
			System.out.println("Carte FNTE\t: ");
			fnte = sc.nextLine();
			
			System.out.println("Cheval preferé n°1\t: ");
			pref1 = sc.nextLine();
			
			System.out.println("Cheval preferé n°2\t: ");
			pref2 = sc.nextLine();
			
			System.out.println("Cheval preferé n°3\t: ");
			pref3 = sc.nextLine();
			
		// presentation
			
			System.out.print("\n\nCavalier n°"+fnte+":");
			System.out.println("\n\t"+ prenom +"\s"+nom);
			System.out.println("\t"+adresse);
			System.out.println("\t Chevaux prefere : "+pref1+"\s"+pref2+"\s"+pref3);
			
			// message de fin
			
			System.out.print("\n\nVoulez-vous continuer (O/N)?");
			rep = sc.nextLine().charAt(0);
						
		} while (rep == 'o');
		
		sc.close();
		
		

	}

}
